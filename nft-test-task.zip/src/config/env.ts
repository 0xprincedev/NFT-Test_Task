export const PROJECT_ID: string = process.env.NEXT_PUBLIC_PROJECT_ID as string
export const API_URL: string = process.env.NEXT_PUBLIC_API_URL as string
export const GRAPHQL_URL: string = process.env.NEXT_PUBLIC_GRAPHQL_URL as string
