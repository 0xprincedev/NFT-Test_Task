import Image from 'next/image'
import React from 'react'
import AssetImage from '@/assets/images/asset.png'
import AvatarImage from '@/assets/images/avatar.png'
import { shortenAddress } from '@/helpers/shorten-address'
import { TNft } from '@/types/asset'

const NFT: React.FC<{ nft: TNft }> = ({ nft }) => {
  return (
    <div className='space-y-5 rounded-[20px] bg-[#343444] p-5'>
      <Image src={AssetImage} alt='' className='aspect-square rounded-[20px] object-cover' />
      <div className='space-y-4'>
        <h3 className='truncate text-lg/[26px] font-bold'>Token ID: {nft.tokenId}</h3>
        <div className='flex items-center gap-3'>
          <div className='size-11 overflow-hidden rounded-[15px] bg-[#7a798a]'>
            <Image src={AvatarImage} alt='' className='h-full w-full object-cover' />
          </div>
          <div className='space-y-0.5'>
            <p className='text-[13px]/5 text-[#8a8aa0]'>Creator</p>
            <p className='text-[15px]/[22px] font-bold text-[#ebebeb]'>
              {shortenAddress(nft.owner.id)}
            </p>
          </div>
          <div className='ml-auto rounded-lg bg-primary px-3 py-0.5 text-xs/5 font-bold'>
            Sepolia
          </div>
        </div>
      </div>
    </div>
  )
}

export default NFT
