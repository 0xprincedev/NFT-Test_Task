export type TNft = {
  tokenId: string
  owner: {
    id: string
  }
}
